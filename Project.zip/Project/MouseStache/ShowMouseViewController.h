//
//  ShowMouseViewController.h
//  MouseStache
//
//  Created by Danielle Bessler on 2/20/14.
//  Copyright (c) 2014 Danielle Bessler. All rights reserved.
//

#import <UIKit/UIKit.h>

@class Mouse;


@interface ShowMouseViewController : UITableViewController

@property (nonatomic, strong) Mouse *mouse;


@end
